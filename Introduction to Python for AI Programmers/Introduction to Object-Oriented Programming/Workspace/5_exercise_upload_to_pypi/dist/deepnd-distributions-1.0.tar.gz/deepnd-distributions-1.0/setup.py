from setuptools import setup

setup(name='deepnd-distributions',
      version='1.0',
      description='Gaussian distributions',
      author= 'Israel Fitsum',
      packages=['deepnd-distributions'],
      zip_safe=False)
